<!DOCTYPE php>
<php class="no-js">
    
    <head>
        <title>Admin Panel</title>
        <!-- Bootstrap -->
		<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->theme->baseUrl; ?>/bootstrap/css/bootstrap.min.css" media="screen"/>
        <link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->theme->baseUrl; ?>/bootstrap/css/bootstrap-responsive.min.css" media="screen"/>
		<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->theme->baseUrl; ?>/vendors/easypiechart/jquery.easy-pie-chart.css" media="screen"/>
        <link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->theme->baseUrl; ?>/assets/styles.css" media="screen"/>
        <link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->theme->baseUrl; ?>/assets/additional.css" media="screen"/>
		<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->theme->baseUrl; ?>/vendors/fullcalendar/fullcalendar.css" media="screen"/>
		
		
        
        <!-- php5 shim, for IE6-8 support of php5 elements -->
        <!--[if lt IE 9]>
            <script src="http://php5shim.googlecode.com/svn/trunk/php5.js"></script>
        <![endif]-->
		
       
    </head>
    
    <body>
        <div class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container-fluid">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                    </a>
                    <?php $userid=Yii::app()->user->getState("userid");?>
                    <a class="brand" href="#">Admin Panel</a>
                    <div class="nav-collapse collapse">
                        <ul class="nav pull-right">
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-user"></i> <?php echo ucwords(Yii::app()->user->name)?> <i class="caret"></i></a>
								
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="<?php echo Yii::app()->createUrl("/user/update/$userid") ?>">Profile</a>
                                    </li>
									<li>
										<a href="<?php echo Yii::app()->createUrl("/user/change_password/$userid") ?>">
											Change Password
										</a>
									</li>
                                    <li class="divider"></li>
                                    <li>
                                        <a tabindex="-1" href="<?php echo Yii::app()->createUrl("/site/logout") ?>">Logout</a>
                                    </li>
                                </ul>
                            </li>

                            <li>
                                <a href="<?php echo Yii::app()->createUrl("/user/change_password/$userid") ?>">
                                            Change Password
                                        </a>
                            </li>
                            <li>
                                <a tabindex="-1" href="<?php echo Yii::app()->createUrl("/site/logout") ?>">Logout</a>
                            </li>
                        </ul>

                    </div>
                    <!--/.nav-collapse -->
                </div>
            </div>
        </div>
  