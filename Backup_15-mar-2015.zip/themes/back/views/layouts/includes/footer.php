<!--<hr>
            <footer class="navbar-inner">
				<p style="margin:10px 0;">
					Admin Panel
				</p>
            </footer>-->
        
        <!--/.fluid-container-->
	<!--	<script type="text/javascript" src="<?php echo Yii::app()->theme->baseUrl; ?>/vendors/modernizr-2.6.2-respond-1.1.0.min.js" ></script>
		
<script type="text/javascript" src="<?php echo Yii::app()->theme->baseUrl; ?>/vendors/jquery-ui-1.10.3.js" ></script>
		<script type="text/javascript" src="<?php echo Yii::app()->theme->baseUrl; ?>/bootstrap/js/bootstrap.min.js" ></script>
		<script type="text/javascript" src="<?php echo Yii::app()->theme->baseUrl; ?>/vendors/easypiechart/jquery.easy-pie-chart.js" ></script>
		
		<script type="text/javascript" src="<?php echo Yii::app()->theme->baseUrl; ?>/vendors/jquery-ui-1.10.3.js" ></script>
		<script type="text/javascript" src="<?php echo Yii::app()->theme->baseUrl; ?>/vendors/fullcalendar/fullcalendar.js" ></script>
		<script type="text/javascript" src="<?php echo Yii::app()->theme->baseUrl; ?>/vendors/fullcalendar/gcal.js" ></script>
	

		<script type="text/javascript" src="<?php echo Yii::app()->theme->baseUrl; ?>/bootstrap/js/bootstrap.min.js" ></script>
		<script type="text/javascript" src="<?php echo Yii::app()->theme->baseUrl; ?>/assets/scripts.js" ></script>
		<script type="text/javascript" src="<?php echo Yii::app()->theme->baseUrl; ?>/assets/form-validation.js" ></script>

		-->
		<!--end stats-->
		
		
    
    </body>

</html>