<?php 
	$controller	= Yii::app()->controller->id;
	$action		= Yii::app()->controller->action->id;
	$url = Yii::app()->theme->baseUrl; 
?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo CHtml::encode($this->pageTitle); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">      
	<meta name="author" content="Html5TemplatesDreamweaver.com">
	<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW"> <!-- Remove this Robots Meta Tag, to allow indexing of site -->
    
  
   <!-- CSS Part Start-->
    <link rel="stylesheet" type="text/css" href="<?php echo $url; ?>/css/stylesheet.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo $url; ?>/css/slideshow.css" media="screen" />
   
    <link rel="stylesheet" type="text/css" href="<?php echo $url; ?>/css/carousel.css" media="screen" />
        <link rel="stylesheet" href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css" />
        <link type="text/css" rel="stylesheet" href="<?php echo $url ?>/popup/css/style.css" />

       
    <!-- CSS Part End-->

  <style type="text/css">

  .alert-success {
    background-color: #dff0d8;
    border-color: #d6e9c6;
    color: #468847;
}

.alert {

    border-radius: 4px;
    margin-bottom: 20px;
    padding: 8px 35px 8px 14px;
    text-shadow: 0 1px 0 rgba(255, 255, 255, 0.5);
}
  </style>
  
 


    <!-- 




    JS Part Start-->
    <script type="text/javascript" src="<?php echo $url; ?>/js/jquery-1.7.1.min.js"></script>
    <script type="text/javascript" src="<?php echo $url; ?>/js/jquery.nivo.slider.pack.js"></script>
    <script type="text/javascript" src="<?php echo $url; ?>/js/jquery.jcarousel.min.js"></script>
    <script type="text/javascript" src="<?php echo $url; ?>/js/colorbox/jquery.colorbox-min.js"></script>
   <script type="text/javascript" src="<?php echo $url; ?>/js/tabs.js"></script>
     <script type="text/javascript" src="<?php echo $url; ?>/js/jquery.easing-1.3.min.js"></script>
    <script type="text/javascript" src="<?php echo $url; ?>/js/cloud_zoom.js"></script>
    
<!--   -->
    <script type="text/javascript" src="<?php echo $url; ?>/js/custom.js"></script>
    <script type="text/javascript" src="<?php echo $url; ?>/js/jquery.dcjqaccordion.js"></script>

   

  <!--  <script type="text/javascript" src="<?php echo $url ?>/popup/js/jquery-1.11.0.min.js"></script>
 -->
<script type="text/javascript" src="<?php echo $url ?>/popup/js/jquery.leanModal.min.js"></script>

 
   <!--  JS Part End-->
    
</head>
<body>    	
<div class="main-wrapper">
    <?php	

    $this->renderPartial("//site/header");

 		echo $content; 
echo '</div>';
	$this->renderPartial("//site/footer");	

	?>

</body>

</html>
  