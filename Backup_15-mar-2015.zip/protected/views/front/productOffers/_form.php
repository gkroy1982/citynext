<?php
/* @var $this ProductOffersController */
/* @var $model ProductOffers */
/* @var $form CActiveForm */
?>



<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'product-offers-form',
	'htmlOptions'=>array('class'=>'form-horizontal','enctype' => 'multipart/form-data'),
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>


	<div class="row">
		<label class="control-label">
		<?php echo $form->labelEx($model,'product_id'); ?>
		</label>
		<div class="controls">
		<?php 

		$products=CHtml::listData(Products::model()->findAll(array('condition'=>'status="active" and user_id='.Yii::app()->user->getState('uid'), "order"=>"product")),'pid', 'product');
		 ?>

		<?php echo $form->dropDownList($model,'product_id',$products,array('empty'=>'select')); ?>
		<?php echo $form->error($model,'product_id'); ?>
		</div>
	</div>

	<div class="row">
		<label class="control-label">
		<?php echo $form->labelEx($model,'offer_id'); ?>
		</label>
		<div class="controls">
		
		<?php echo $form->dropDownList($model,'offer_id',Offer::getOffer(),array('empty'=>'select')); ?>
		<?php echo $form->error($model,'offer_id'); ?>
		</div>
	</div>

	<div class="row">
		<label class="control-label">
		<?php echo $form->labelEx($model,'description'); ?>
		</label>
		<div class="controls">
		<?php echo $form->textArea($model,'description',array('class'=>'tinymce_full','rows'=>6, 'cols'=>50)); ?>
		<?php echo $form->error($model,'description'); ?>
		</div>
	</div>

	<div class="row">
		<label class="control-label">
		<?php echo $form->labelEx($model,'start_date'); ?>
		</label>
		<div class="controls">
		
		<?php echo $form->textField($model,'start_date'); ?>
		<?php echo $form->error($model,'start_date'); ?>
		</div>
	</div>


	<div class="row buttons">
		<div class="controls">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save',array('class'=>'btn btn-primary')); ?>
		</div>
	</div>

<?php $this->endWidget(); ?>

