  <div id="container">
   <?php $this->renderPartial('left');?>
    <!--Middle Part Start-->
    <!--Middle Part Start-->
    <div id="content">
      <!--Breadcrumb Part Start-->
      <div class="breadcrumb"><a href="index.html">Home</a> » <a href="about-us.html">Sell Now</a></div>
      <!--Breadcrumb Part End-->
      <h1>Sell Now</h1>
      <p>Page under Construction </p>
    </div>
    <!--Middle Part End-->
    <div class="clear"></div>
    <div class="social-part">
     
    </div>
  </div>