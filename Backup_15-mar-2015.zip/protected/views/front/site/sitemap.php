  <div id="container">
   <?php $this->renderPartial('left');?>
    <!--Middle Part Start-->
    <div id="content">
      <!--Breadcrumb Part Start-->
      <div class="breadcrumb"><a href="index.html">Home</a> » <a href="sitemap.html">Site Map</a></div>
      <!--Breadcrumb Part End-->
      <h1>Site Map</h1>
      <div class="sitemap-info">
        <div class="left">
          <ul class="sitemap">
            <li><a href="category.html">Desktops</a>
              <ul>
                <li><a href="category.html">PC</a> </li>
                <li><a href="category.html">Mac</a> </li>
              </ul>
            </li>
            <li><a href="category.html">Laptops &amp; Notebooks</a>
              <ul>
                <li><a href="category.html">Macs</a> </li>
                <li><a href="category.html">Windows</a> </li>
              </ul>
            </li>
            <li><a href="category.html">Components</a>
              <ul>
                <li><a href="category.html">Mice and Trackballs</a> </li>
                <li><a href="category.html">Monitors</a>
                  <ul>
                    <li><a href="category.html">test 1</a></li>
                    <li><a href="category.html">test 2</a></li>
                  </ul>
                </li>
                <li><a href="category.html">Printers</a> </li>
                <li><a href="category.html">Scanners</a> </li>
                <li><a href="category.html">Web Cameras</a> </li>
              </ul>
            </li>
            <li><a href="category.html">Tablets</a> </li>
            <li><a href="category.html">Software</a> </li>
            <li><a href="category.html">Phones &amp; PDAs</a> </li>
            <li><a href="category.html">Cameras</a> </li>
            <li><a href="category.html">MP3 Players</a>
              <ul>
                <li><a href="category.html">test 11</a> </li>
                <li><a href="category.html">test 12</a> </li>
                <li><a href="category.html">test 15</a> </li>
                <li><a href="category.html">test 16</a> </li>
                <li><a href="category.html">test 17</a> </li>
                <li><a href="category.html">test 18</a> </li>
                <li><a href="category.html">test 19</a> </li>
                <li><a href="category.html">test 20</a>
                  <ul>
                    <li><a href="category.html">test 25</a></li>
                  </ul>
                </li>
                <li><a href="category.html">test 21</a> </li>
                <li><a href="category.html">test 22</a> </li>
                <li><a href="category.html">test 23</a> </li>
                <li><a href="category.html">test 24</a> </li>
                <li><a href="category.html">test 4</a> </li>
                <li><a href="category.html">test 5</a> </li>
                <li><a href="category.html">test 6</a> </li>
                <li><a href="category.html">test 7</a> </li>
                <li><a href="category.html">test 8</a> </li>
                <li><a href="category.html">test 9</a> </li>
              </ul>
            </li>
          </ul>
        </div>
        <div class="right">
          <ul class="sitemap">
            <li><a href="#">Special Offers</a></li>
            <li><a href="#">My Account</a>
              <ul>
                <li><a href="#">Account Information</a></li>
                <li><a href="#">Password</a></li>
                <li><a href="#">Address Book</a></li>
                <li><a href="#">Order History</a></li>
                <li><a href="#">Downloads</a></li>
              </ul>
            </li>
            <li><a href="#">Shopping Cart</a></li>
            <li><a href="checkout.html">Checkout</a></li>
            <li><a href="#">Search</a></li>
            <li>Information
              <ul>
                <li><a href="about-us.html">About Us</a></li>
                <li><a href="about-us.html">Delivery Information</a></li>
                <li><a href="about-us.html">Privacy Policy</a></li>
                <li><a href="about-us.html">Terms &amp; Conditions</a></li>
                <li><a href="contact-us.html">Contact Us</a></li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <!--Middle Part End-->
    <div class="clear"></div>
    <div class="social-part">
     
    </div>
  </div>
