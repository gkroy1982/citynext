﻿<?php $this->pageTitle='Jhansishopping.com | Product Details';?>
<?php 

$url = Yii::app()->theme->baseUrl; 
$url_product = Yii::app()->baseUrl.'/upload/sell/'; 
$url_img = Yii::app()->basePath.'/../upload/sell/'; 
?>

   <?php $this->renderPartial('left');?>
  
<!--Middle Part Start-->
    <div id="content">

      <!--Breadcrumb Part Start-->
      <div class="breadcrumb"> <a href="<?php echo Yii::app()->createUrl('site/index')?>">Home</a> » <a href="<?php echo Yii::app()->createUrl('sale/subcategories',array('id'=>$product->main_category_id))?>"><?php echo $product->mainCategory->category?></a> » <a href="<?php echo Yii::app()->createUrl('sale/products',array('id'=>$product->sub_category_id))?>"> <?php echo $product->subCategory->sub_category.'</a> » '.$product->product?>
       
      <?php $this->renderPartial('post_sell');?>

      </div>
      <!--Breadcrumb Part End-->
      <div class="product-info">


        <div class="left">

          <?php 
          if (file_exists($url_img.$product->image) and $product->image!='') 
          {
              ?>
              <div  id='image1'>               
                  <img style="width:100%;max-height:450px;" src="<?php echo $url_product.$product->image;?>"  />              
              </div>
              <?php
          }
          ?>
          <?php 
          if (file_exists($url_img.$product->image2) and $product->image2!='') 
          {
              ?>
              <div  id='image2' style="display:none;">                
                  <img style="width:100%;max-height:450px;" src="<?php echo $url_product.$product->image2;?>" />              
              </div>
              <?php
          }
          ?>
          <?php 
          if (file_exists($url_img.$product->image3) and $product->image3!='') 
          {
              ?>
              <div  id='image3' style="display:none;">               
                  <img style="width:100%;max-height:450px;" src="<?php echo $url_product.$product->image3;?>" />              
              </div>
              <?php
          }
          ?>

          <div class="image-additional"> 
          <?php 
          if (file_exists($url_img.$product->image) and $product->image!='') 
          {
              ?>
              <a onClick='fun("image1")' class="cloud-zoom-gallery"> 
              <img src="<?php echo $url_product.$product->image ?>" width="40" /></a> 
              <?php
          }
          ?>
          <?php 
          if (file_exists($url_img.$product->image2) and $product->image2!='') 
          {
              ?>
              <a onClick='fun("image2")'  class="cloud-zoom-gallery"> 
              <img src="<?php echo $url_product.$product->image2 ?>" width="40" /></a> 
              <?php
          }
          ?>
          <?php 
          if (file_exists($url_img.$product->image3) and $product->image3!='') 
          {
              ?>
              <a onClick='fun("image3")' class="cloud-zoom-gallery" > 
              <img src="<?php echo $url_product.$product->image3 ?>" width="40"/></a>
              <?php
          }
          ?>
           </div>
        </div>
<script type="text/javascript">
  
  function fun( tmp )
  {
    if(tmp=='image1')
    {
        $('#image3').hide();
        $('#image2').hide();
        $('#image1').show();
    }
    if(tmp=='image2')
    {
        $('#image3').hide();        
        $('#image1').hide();
        $('#image2').show();
    }
    if(tmp=='image3')
    {
        $('#image1').hide();
        $('#image2').hide();
        $('#image3').show();  
    }
      
  }
</script>

        <div class="right">
          <h1><?php echo ucwords($product->product)?></h1>
          <div class="cart"> 
            
            <span>Product Price: Rs.</span> <?php echo $product->price?><br>
            <span>Availability:</span> In Stock</div>
                     
         <?php 
          $offer = Productoffers::model()->findAll(array('condition'=>'status="active" and product_id='.$product->pid ) );

          foreach ($offer as $off ) 
          {  
               ?>
              <div class="cart"><h2>Offer</h2>             
                <?php echo $off->description; ?>
              </div>
              <?php
          } ?>
<!--
          <div class="cart">
            <div>
              <div class="qty"> <strong>Qty:</strong> <a href="javascript:void(0);" class="qtyBtn mines">-</a>
                <input type="text" value="1" size="2" name="quantity" class="w30" id="qty">
                <a href="javascript:void(0);" class="qtyBtn plus">+</a>
                <div class="clear"></div>
              </div>
              <input type="button" class="button" id="button-cart" value="Add to Cart">
            </div>
            <div><span>&nbsp;&nbsp;&nbsp;- OR -&nbsp;&nbsp;&nbsp;</span></div>
            <div><a href="#" class="wishlist">Add to Wish List</a><br>
              <a href="#" class="wishlist">Add to Compare</a></div>
          </div>
          <div class="review">
            <div><img alt="0 reviews" src="<?php echo $url ?>/image/stars-3.png">&nbsp;&nbsp;<a onClick="$('a[href=\'#tab-review\']').trigger('click');">0 reviews</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a onClick="$('a[href=\'#tab-review\']').trigger('click');">Write a review</a></div>
          </div>-->
          <!-- AddThis Button BEGIN -->
          <!--<div class="addthis_toolbox addthis_default_style "> 
              <a class="addthis_button_facebook_like" fb:like:layout="button_count"></a> 
              <a class="addthis_button_tweet"></a> <a class="addthis_button_pinterest_pinit"></a>
              <a class="addthis_counter addthis_pill_style"></a> 
           </div>-->
          <script type="text/javascript" src="../../../s7.addthis.com/js/300/addthis_widget.js#pubid=xa-506f325f57fbfc95"></script>
          <!-- AddThis Button END -->
          <!--<div class="tags"> 
          <b>Tags:</b> <a href="#">Apple</a>, 
          <a href="#">Mobile</a>, <a href="#">Latest</a>
           </div> -->
        </div>
      </div>


      <!-- Tabs Start -->

      <div id="tabs" class="htabs"> <a href="#tab-description">Description</a> <!--<a href="#tab-review">Reviews</a>--> </div>
      <div id="tab-description" class="tab-content">        
          <?php echo $product->description;?>
      </div>
      <!--
      <div class="tab-content" id="tab-review">
        <div class="review-list">
          <div class="author"><b>Harnish</b> on  13/02/2014</div>
          <div class="rating"><img alt="1 reviews" src="<?php echo $url ?>/image/stars-3.png"></div>
          <div class="text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled.</div>
        </div>
        <h2 id="review-title">Write a review</h2>
        <br>
        <b>Your Name:</b><br>
        <input type="text" value="" name="name">
        <br>
        <br>
        <b>Your Review:</b>
        <textarea style="width: 98%;" rows="8" cols="40" name="text"></textarea>
        <span style="font-size: 11px;"><span style="color: #FF0000;">Note:</span> HTML is not translated!</span><br>
        <br>
        <b>Rating:</b>&nbsp;
        <input type="radio" value="1" name="rating">
        &nbsp;
        <input type="radio" value="2" name="rating">
        &nbsp;
        <input type="radio" value="3" name="rating">
        &nbsp;
        <input type="radio" value="4" name="rating">
        &nbsp;
        <input type="radio" value="5" name="rating">
        <br>
        <br>
        <div class="buttons">
          <div class="right"><a class="button" id="button-review">Continue</a></div>
        </div>
      </div> -->
      <!-- Tabs End -->



      <!-- Related Products Start -->
<!--

      <div class="box">
        <div class="box-heading">Related Products (4)</div>
        <div class="box-content">
          <div class="box-product">
            <div>
              <div class="image"><a href="product.html"><img alt="iPad Classic" src="<?php echo $url ?>/image/product/ipod_classic_1-152x152.jpg"></a></div>
              <div class="name"><a href="product.html">iPad Classic</a></div>

            </div>
            <div>
              <div class="image"><a href="product.html"><img alt="Sports Watch Band" src="<?php echo $url ?>/image/product/samsung_syncmaster_941bw-152x152.jpg"></a></div>
              <div class="name"><a href="product.html">Sports Watch Band</a></div>
              
            </div>
            <div>
              <div class="image"><a href="product.html"><img alt="iPhone" src="<?php echo $url ?>/image/product/iphone_1-152x152.jpg"></a></div>
              <div class="name"><a href="product.html">iPhone</a></div>
              
            </div>
            <div>
              <div class="image"><a href="product.html"><img alt="Casual Saddle Shoes" src="<?php echo $url ?>/image/product/hp_1-152x152.jpg"></a></div>
              <div class="name"><a href="product.html">Casual Saddle Shoes</a></div>
              
            </div>
          </div>
        </div>
      </div> -->
      <!-- Related Products End -->
    </div>
    <!--Middle Part End-->
    <div class="clear"></div>
    <div class="social-part">
     
    </div>
  </div>
</div>




