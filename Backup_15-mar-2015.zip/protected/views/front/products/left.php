﻿<?php 

$url = Yii::app()->theme->baseUrl; 

 $letest = Products::model()->findAll();
 $specials = Products::model()->findAll();
 $p_url=Yii::app()->baseUrl.'/upload/products/'; 
//$products=array();

  $controller = Yii::app()->controller->id;
    $action     = Yii::app()->controller->action->id;
    $url = Yii::app()->theme->baseUrl; 
  

  if( $controller=='users' and $action=='view')
      $profile_view='active';
    if( $controller=='users' and $action=='update')
      $profile_update='active';


if( $controller=='products')
      $products='active';

if( $controller=='productoffers')
      $productoffers='active';
if( $controller=='ads')
      $ads='active';
if( $controller=='saleproduct')
      $saleproduct='active';

?>





    <!--Left Part-->
    <div id="column-left">
      <!--Categories Part Start-->
     <div class="box">
    <div class="box-heading">Profile</div>

      <div class="box-content box-category">
          <ul id="custom_accordion1">
            <li class="category25 <?php echo $profile_view;?>"><a class="cuuchild " href="<?php echo Yii::app()->createUrl('users/view',array('id'=>Yii::app()->user->getState('uid')));?>">View Profile</a> </li>
            <li class="category18 <?php echo $profile_update;?>"><a class="cuuchild " href="<?php echo Yii::app()->createUrl('users/update',array('id'=>Yii::app()->user->getState('uid')));?>">Update Profile</a></li>                         
          </ul>
        </div>
        <br>



        <div class="box-heading">Menu</div>
        <div class="box-content box-category">
          <ul id="custom_accordion">
	<li class="category25 <?php echo $saleproduct;?>"><span class="down"><a class="cuuchild " href="#">History</a> </span>
        <ul>
		<li class="category30"><a class="nochild " href="#">Product/Service</a></li>
            <li class="category30"><a class="nochild " href="#">Offer Product</a></li>
        </ul>
      </li>


          <?php /*                 
                $mainMenus = MainCategory::model()->findAll();
                foreach($mainMenus as $menu)
                {
                  ?>
                  <li class="category25"><a class="cuuchild " href="<?php echo Yii::app()->createUrl('site/subcategories',array('id'=>$menu->mcid))?>"><?php echo ucwords($menu->category);?></a> <span class="down"></span>
                    <ul>
                  
                        <?php 
                          $submenus = SubCategory::model()->findAll( array('condition'=>'main_category_id='.$menu->mcid));
                          foreach($submenus as $sub)
                          {
                            ?>
                                <li class="category30"><a class="nochild " href="<?php echo Yii::app()->createUrl('site/products',array('id'=>$sub->scid))?>"><?php echo ucwords($sub->sub_category);?></a></li>
                             <?php
                          }
                          ?>
                      </ul>
                  </li>
                  <?php
                }*/
                ?>


                <?php 
    $record=Users::model()->findByPk(Yii::app()->user->getState('uid'));
    
    if(2==$record->user_type)
    {
    ?>
      <li class=" category25 <?php echo $products;?>"><span class="down">
<a class="cuuchild " href="#">Product/Service</a> </span>
        <ul>
            <li class="category30"><a class="nochild " href="<?php echo Yii::app()->createUrl('products/admin')?>">View Product</a></li>
	   <li class="category30"><a class="nochild " href="<?php echo Yii::app()->createUrl('products/create')?>">Add Product</a></li>     
   </ul>
      </li>

      <li class="category25 <?php echo $productoffers;?>"><span class="down"><a class="cuuchild " href="#">Offer Product</a> </span>
        <ul>
            <li class="category30"><a class="nochild " href="<?php echo Yii::app()->createUrl('productoffers/admin')?>">View Product</a></li>
      		   <li class="category30"><a class="nochild " href="<?php echo Yii::app()->createUrl('productoffers/create')?>">Add Product</a></li>
	  </ul>
      </li>

      <li class="category25 <?php echo $ads;?>"><span class="down"><a class="cuuchild " href="#">Home Page Image</a> </span>
        <ul>
		<li class="category30"><a class="nochild " href="<?php echo Yii::app()->createUrl('ads/admin')?>">View Home Page Image</a></li>
            <li class="category30"><a class="nochild " href="<?php echo Yii::app()->createUrl('ads/create')?>">Add Home Page Image</a></li>
        </ul>
      </li>

    <?php 
    } else {
    ?>

    <li class="category25 <?php echo $saleproduct;?>"><a class="cuuchild " href="#">Product/Service</a> <span class="down"></span>
        <ul>
		<li class="category30"><a class="nochild " href="<?php echo Yii::app()->createUrl('saleproduct/admin')?>">View Product</a></li>
            <li class="category30"><a class="nochild " href="<?php echo Yii::app()->createUrl('saleproduct/create')?>">Add Product</a></li>
        </ul>
      </li>
     <?php 
    }
    ?>





          </ul>
        </div>
      </div> 
      <!--Categories Part End-->
      <!--Latest Product Start-->

      <!--
      <div class="box">
        <div class="box-heading">Latest</div>
        <div class="box-content">
          <div class="box-product">

        <?php          
          foreach($letest as $product)
          {
            ?>
            <div>
              <div class="image">
                  <a href="<?php echo Yii::app()->createUrl('site/productdetails',array('id'=>$product->pid));?>">
                  <img style="width:60px;" src="<?php echo $p_url.$product->image;?>"  /></a>
              </div>
              <div class="name">
                <a href="<?php echo Yii::app()->createUrl('site/productdetails',array('id'=>$product->pid));?>"><?php echo ucwords($product->product);?></a>
              </div>
              <div class="price"> <?php echo $product->price;?></div>
             
            </div>
            <?php
          }
          ?>



          </div>
        </div>
      </div>-->
      <!--Latest Product End-->
      <!--Specials Product Start-->
      <!--<div class="box">
        <div class="box-heading">Specials</div>
        <div class="box-content">
          <div class="box-product">

        <?php          
          foreach($specials as $product)
          {
            ?>
            <div>
              <div class="image">
                  <a href="<?php echo Yii::app()->createUrl('site/productdetails',array('id'=>$product->pid));?>">
                  <img style="width:60px;" src="<?php echo $p_url.$product->image;?>"  /></a>
              </div>
              <div class="name">
                <a href="<?php echo Yii::app()->createUrl('site/productdetails',array('id'=>$product->pid));?>"><?php echo ucwords($product->product);?></a>
              </div>
              <div class="price"> <?php echo $product->price;?></div>
             
            </div>
            <?php
          }
          ?>
            
          </div>
        </div>
      </div>
      <!--Specials Product End-->
    </div>
    <!--Left End-->



