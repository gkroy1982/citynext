<style>
.help{
margin:9px;
line-height:25px;
}
.help li{
line-height:22px;
}
</style>
<div class="container-fluid">
	<div class="row-fluid">
		<div class="row-fluid">
			<div class="span12 center">
				<h1>Welcome to Kokan Property Help</h1>
			</div>
			
			<div class="help">
				<h3>Dashboard</h3>
				<ul>
					<li>On <strong>Dashboard</strong> total number of Property ,categories,specialities, & enquiry details are displayed.</li>
					<li>By clicking on any above <strong>Dashboard</strong> admin will be navigated to that particular page.</li>
				</ul>
			</div>
			
		
			
			
			<!--/span-->
		</div>
		<!--/row-->
		<div class="row-fluid">
			<!--/span-->
		</div>
		<!--/row-->
	</div>
	<!--/fluid-row-->
</div>


