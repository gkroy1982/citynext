<?php
/* @var $this AdsController */
/* @var $model Ads */

$this->breadcrumbs=array(
	'Ads'=>array('admin'),
	'Update',
);

$this->menu=array(
	array('label'=>'Create Ads', 'url'=>array('create')),
	array('label'=>'View Ads', 'url'=>array('view', 'id'=>$model->aid)),
	array('label'=>'List Ads', 'url'=>array('admin')),
);
$this->title="Update Ads";
?>


<?php $this->renderPartial('_form', array('model'=>$model)); ?>