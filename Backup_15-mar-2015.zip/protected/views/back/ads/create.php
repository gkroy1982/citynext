<?php
/* @var $this AdsController */
/* @var $model Ads */

$this->breadcrumbs=array(
	'Ads'=>array('admin'),
	'Create',
);

$this->menu=array(
	array('label'=>'List Ads', 'url'=>array('admin')),
);
$this->title="Create Ads";
?>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>