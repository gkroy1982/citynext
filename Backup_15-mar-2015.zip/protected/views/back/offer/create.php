<?php
/* @var $this OfferController */
/* @var $model Offer */

$this->breadcrumbs=array(
	'Offers'=>array('admin'),
	'Create',
);

$this->menu=array(
	array('label'=>'List Offer', 'url'=>array('admin')),
);
$this->title="Create Offer";
?>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>