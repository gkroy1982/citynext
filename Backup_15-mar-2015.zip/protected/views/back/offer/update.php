<?php
/* @var $this OfferController */
/* @var $model Offer */

$this->breadcrumbs=array(
	'Offers'=>array('admin'),
	'Update',
);

$this->menu=array(
	array('label'=>'Create Offer', 'url'=>array('create')),
	array('label'=>'View Offer', 'url'=>array('view', 'id'=>$model->oid)),
	array('label'=>'List Offer', 'url'=>array('admin')),
);
$this->title="Update Offer";
?>


<?php $this->renderPartial('_form', array('model'=>$model)); ?>